package com.qa.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrangeHRMPages {
	 WebDriver driver;
	 
		@FindBy(id = "txtUsername")
		WebElement OrangeUserID;
		
		@FindBy(id = "txtPassword")
		WebElement OrangePassword;
		
		@FindBy(id = "btnLogin")
		WebElement OrangeLoginBtn;
		
		@FindBy(xpath="//div[@class='head']/h1")
		WebElement DashBoardText;
		
		@FindAll(@FindBy(className="sbct"))
		List<WebElement> searchresult;
		
		
		public void EnterUserId(String text)
		{
			OrangeUserID.sendKeys(text); 	
		}
		
		public void EnterPassword(String text)
		{
			OrangePassword.sendKeys(text); 	
		}
		
		public void ClickLoginBtn()
		{
			OrangeLoginBtn.click();
		}
		
		public OrangeHRMPages(WebDriver driver)
		{
		  this.driver = driver;
		  PageFactory.initElements(driver, this);  
		}

		

}
