package assignment;

import java.util.List;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Assign1 {

	public static void main(String[] args) {
		 WebDriver driver;
		 System.setProperty("webdriver.gecko.driver", "./BrowserDriver/geckodriver.exe");

	     driver = new FirefoxDriver();
	     driver.get("https://opensource-demo.orangehrmlive.com/");
	     driver.manage().window().maximize();
	     
	     System.out.print("Title of the launched application- " +driver.getTitle() );
	     
	     List<WebElement> Txtobj = driver.findElements(By.xpath("//input"));
	     System.out.println("Displaying all text box attribute name ");
	     for (WebElement lstTxt : Txtobj)
	     {
	    	 System.out.println(lstTxt.getAttribute("name"));
	     }
	     
	     List<WebElement> lnkobj = driver.findElements(By.xpath("//a"));
	     System.out.println("Displaying all Link text ");
	     for (WebElement lstLnk : lnkobj)
	     {
	    	 if (!lstLnk.getText().isEmpty())
	    	 {
	    	   System.out.println(lstLnk.getText());
	    	 }
	     }
	     
	     List<WebElement> imgobj = driver.findElements(By.cssSelector("img"));
	     System.out.println("Displaying all Image src text ");
	     for (WebElement lstimg : imgobj)
	     {
	    	 System.out.println(lstimg.getAttribute("src"));
	     }
	     
	     driver.findElement(By.id("txtUsername")).sendKeys("Admin");
	     driver.findElement(By.id("txtPassword")).sendKeys("admin123");
	     driver.findElement(By.id("btnLogin")).click();
	     
	     WebDriverWait wait = new WebDriverWait(driver, 10);
	     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='head']/h1")));
	     
	     String HeadTxt = driver.findElement(By.xpath("//div[@class='head']/h1")).getText();
	     if (HeadTxt.equals("Dashboard"))
	     {
	    	 System.out.println("Dashboard is displayed");
	     }
	     else
	     {
	    	 System.out.println("Dashboard is not displayed");
	     }
	     
	     
	     WebElement element = driver.findElement(By.xpath("//*[@id='menu_admin_viewAdminModule']/b"));
	  
	     JavascriptExecutor executor = (JavascriptExecutor)driver;
	     executor.executeScript("arguments[0].click();", element);
	     
	     List<WebElement> Menuitems = driver.findElements(By.xpath("//li[@class='current main-menu-first-level-list-item']//a"));
         for (WebElement item : Menuitems)
         {
        	 String menutxt = item.getText();
        	 if (menutxt.equals("User Management"))
        	 {
        		 System.out.println("User Management menu item verified");
        		 continue; 
        	 }
        	 if (menutxt.equals("Job"))
        	 {
        		 System.out.println("Job menu item verified");
        		 continue;
        	 }
        	 if (menutxt.equals("Organization"))
        	 {
        		 System.out.println("Organization menu item verified");
        		 continue;
        	 }
        	 if (menutxt.equals("Qualifications"))
        	 {
        		 System.out.println("Qualifications menu item verified");
        		 continue;
        	 }
         }
	     
	     driver.quit();
	      
	}

}