package com.qa.testscripts;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeSuite;

public class TestNGAssign {
	WebDriver driver;
  
  @BeforeSuite
  public void beforeSuite() 
  {
	  System.setProperty("webdriver.gecko.driver", "./BrowserDriver/geckodriver.exe");
	  driver = new FirefoxDriver();
	  driver.get("https://opensource-demo.orangehrmlive.com/");
	  driver.manage().window().maximize();
   }


  @Test (priority = 0)
  public void login()  {
	   driver.findElement(By.id("txtUsername")).sendKeys("Admin");
	   driver.findElement(By.id("txtPassword")).sendKeys("admin123");
	   driver.findElement(By.id("btnLogin")).click();
	     
	   WebDriverWait wait = new WebDriverWait(driver, 10);
	   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='head']/h1")));
	     
	   String HeadTxt = driver.findElement(By.xpath("//div[@class='head']/h1")).getText();
	   if (HeadTxt.equals("Dashboard"))
	     {
	    	 System.out.println("Dashboard is displayed");
	     }
	   else
	     {
	    	 System.out.println("Dashboard is not displayed");
	     }
	     
    }

  
  @Test (priority = 1)
  public void verifyPageTitles()  {
	   driver.findElement(By.id("txtUsername")).sendKeys("Admin");
	   driver.findElement(By.id("txtPassword")).sendKeys("admin123");
	   driver.findElement(By.id("btnLogin")).click();
	     
	   WebDriverWait wait = new WebDriverWait(driver, 10);
	   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='head']/h1")));
	     
	   String HeadTxt = driver.findElement(By.xpath("//div[@class='head']/h1")).getText();
	   if (HeadTxt.equals("Dashboard"))
	     {
	    	 System.out.println("Dashboard is displayed");
	     }
	   else
	     {
	    	 System.out.println("Dashboard is not displayed");
	     }
	     
    }

}
